# Manual IBM — Motor de investigación médica (GitHub Actions)

Este repositorio contiene únicamente el motor de recopilación documental. La app Android y su base de datos local no se migran a GitHub.

## Contenido

- `.github/workflows/research-engine.yml`: ejecución manual y automática diaria.
- `.github/workflows/seed-backlog.yml`: carga manual, inicial y sin duplicados de la cola de 400 entidades.
- `cloud_medical_research/`: worker Node.js, pruebas y documentación.
- `data/medical_research_backlog.json`: cola priorizada generada por la auditoría de Manual IBM.

## Configuración

1. Añade el secreto `FIREBASE_SERVICE_ACCOUNT_JSON` en Settings → Secrets and variables → Actions.
2. Opcionalmente añade `NCBI_EMAIL`.
3. Revisa primero el alcance IAM de la cuenta de servicio. Firebase Admin SDK omite las reglas Firestore; `roles/datastore.user` no limita el acceso a colecciones específicas. No uses una cuenta propietaria ni una cuenta que pueda publicar la biblioteca canónica.
4. Ejecuta una vez **Actions → Manual IBM - Cargar cola inicial → Run workflow**.
5. Ejecuta **Actions → Manual IBM - Investigación médica → Run workflow** para la primera prueba.

No agregues claves JSON ni credenciales al repositorio. No actives servicios Cloud Run, Cloud Build, Artifact Registry o Cloud Scheduler.

Los expedientes se guardan en `medical_research_packets` con estado `needs_review`. Este motor no escribe en la biblioteca global oficial.

Consulta `cloud_medical_research/README.md` para detalles, límites y pruebas.
