'use strict';

let admin;
const crypto = require('node:crypto');

const PROJECT_ID = process.env.FIREBASE_PROJECT_ID || 'manual-ibm';
const MAX_JOBS_PER_RUN = Math.max(1, Math.min(3, Number(process.env.MAX_JOBS_PER_RUN || 1)));
const NCBI_TOOL = 'ManualIBMResearchEngine';
const NCBI_EMAIL = process.env.NCBI_EMAIL || '';
const USER_AGENT = 'ManualIBMResearchEngine/0.2 (documentary medical research)';
const LEASE_MS = 10 * 60 * 1000;
const MAX_ABSTRACT_CHARS = 5000;

function initFirebase() {
  admin = require('firebase-admin');
  if (admin.apps.length) return;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (!raw) throw new Error('MISSING_SECRET_FIREBASE_SERVICE_ACCOUNT_JSON');
  let serviceAccount;
  try { serviceAccount = JSON.parse(raw); }
  catch { throw new Error('INVALID_SECRET_FIREBASE_SERVICE_ACCOUNT_JSON'); }
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount), projectId: PROJECT_ID });
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
let ncbiQueue = Promise.resolve();
const sha = value => crypto.createHash('sha256').update(String(value)).digest('hex');
const clean = value => String(value || '').replace(/<[^>]*>/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
const xmlTag = (xml, tag) => {
  const re = new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, 'i');
  const m = String(xml || '').match(re);
  return m ? clean(m[1]) : '';
};

async function ncbiFetch(url, accept = 'application/xml,text/xml,application/json') {
  const task = ncbiQueue.then(async () => {
    await sleep(450);
    const response = await fetch(url, {
      headers: { 'User-Agent': USER_AGENT, 'Accept': accept },
      signal: AbortSignal.timeout(20000)
    });
    if (!response.ok) throw new Error(`NCBI_HTTP_${response.status}`);
    return response;
  });
  ncbiQueue = task.then(() => undefined, () => undefined);
  return task;
}

function buildSearchTerm(name) {
  const safe = clean(name).replace(/[\[\]{}<>]/g, ' ').replace(/\s+/g, ' ').trim();
  if (!safe || safe.length < 3 || safe.length > 120) throw new Error('ENTITY_NAME_NOT_RESEARCHABLE');
  return `("${safe}"[Title/Abstract] OR "${safe}"[MeSH Terms]) AND (humans[MeSH Terms] OR disease[Title/Abstract] OR infection[Title/Abstract] OR bacteria[Title/Abstract] OR virus[Title/Abstract] OR clinical[Title/Abstract])`;
}

async function searchPubMed(name) {
  const searchUrl = new URL('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi');
  searchUrl.search = new URLSearchParams({ db: 'pubmed', term: buildSearchTerm(name), retmax: '8', retmode: 'json', sort: 'relevance', tool: NCBI_TOOL, ...(NCBI_EMAIL ? { email: NCBI_EMAIL } : {}) }).toString();
  const searchResponse = await ncbiFetch(searchUrl.toString(), 'application/json');
  const searchJson = await searchResponse.json();
  const ids = (searchJson.esearchresult && searchJson.esearchresult.idlist) || [];
  if (!ids.length) return [];
  const fetchUrl = new URL('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi');
  fetchUrl.search = new URLSearchParams({ db: 'pubmed', id: ids.join(','), rettype: 'abstract', retmode: 'xml', tool: NCBI_TOOL, ...(NCBI_EMAIL ? { email: NCBI_EMAIL } : {}) }).toString();
  const xml = await (await ncbiFetch(fetchUrl.toString())).text();
  return xml.split(/<PubmedArticle>/i).slice(1).map(block => {
    const pmid = xmlTag(block, 'PMID');
    const title = xmlTag(block, 'ArticleTitle');
    const abstract = [...block.matchAll(/<AbstractText(?:\s+[^>]*)?>([\s\S]*?)<\/AbstractText>/gi)].map(m => clean(m[1])).join(' ').slice(0, MAX_ABSTRACT_CHARS);
    const year = (block.match(/<PubDate>[\s\S]*?<Year>(\d{4})<\/Year>/i) || [])[1] || '';
    const journal = xmlTag(block, 'Title');
    const doi = (block.match(/<ArticleId IdType="doi">([^<]+)<\/ArticleId>/i) || [])[1] || '';
    if (!pmid || !title) return null;
    const url = `https://pubmed.ncbi.nlm.nih.gov/${encodeURIComponent(pmid)}/`;
    return { sourceName: 'PubMed (NCBI)', sourceType: 'biomedical_literature_record', sourceUrl: url, title, pmid, doi: clean(doi), publicationYear: year, journal, abstract, language: 'en_or_original_not_normalized', retrievedAt: new Date().toISOString(), evidenceHash: sha(url + '|' + title + '|' + abstract) };
  }).filter(Boolean);
}

async function searchBookshelf(name) {
  const term = `"${clean(name).replace(/["\[\]{}]/g, ' ')}"`;
  const url = new URL('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi');
  url.search = new URLSearchParams({ db: 'books', term, retmax: '5', retmode: 'json', tool: NCBI_TOOL, ...(NCBI_EMAIL ? { email: NCBI_EMAIL } : {}) }).toString();
  const data = await (await ncbiFetch(url.toString(), 'application/json')).json();
  return ((data.esearchresult && data.esearchresult.idlist) || []).map(id => ({ sourceName: 'NCBI Bookshelf', sourceType: 'bookshelf_catalog_match', sourceUrl: `https://www.ncbi.nlm.nih.gov/books/${encodeURIComponent(id)}/`, title: `NCBI Bookshelf record ${id}`, bookshelfId: id, abstract: '', language: 'not_determined', retrievedAt: new Date().toISOString(), evidenceHash: sha(`books:${id}`), note: 'Coincidencia de catálogo; requiere abrir y revisar el capítulo antes de usarlo como evidencia.' }));
}

async function claimJob(ref, db) {
  const FieldValue = admin.firestore.FieldValue;
  return db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    if (!snap.exists) return null;
    const job = snap.data();
    const now = Date.now();
    const expired = job.status === 'running' && Number(job.leaseUntilMs || 0) < now;
    if (job.status !== 'queued' && !expired) return null;
    if (job.status === 'queued' && Number(job.retryAfterMs || 0) > now) return null;
    tx.update(ref, { status: 'running', attempts: Number(job.attempts || 0) + 1, startedAt: FieldValue.serverTimestamp(), leaseUntilMs: now + LEASE_MS, updatedAt: FieldValue.serverTimestamp(), workerVersion: '0.2.0' });
    return { ...job, attempts: Number(job.attempts || 0) + 1 };
  });
}

async function processJob(ref, db) {
  const FieldValue = admin.firestore.FieldValue;
  const job = await claimJob(ref, db);
  if (!job) return { skipped: true, jobId: ref.id };
  const started = Date.now();
  try {
    const entityKey = clean(job.entityKey || ref.id);
    const name = clean(job.entityName || job.name);
    if (!entityKey || !name || /SIN DENOMINACI[ÓO]N|REGISTRO ORIGINAL/i.test(name)) throw new Error('ENTITY_REQUIRES_MANUAL_IDENTIFICATION');
    const [pubmed, bookshelf] = await Promise.all([searchPubMed(name), searchBookshelf(name)]);
    const allEvidence = [...pubmed, ...bookshelf];
    const batch = db.batch();
    for (const evidence of allEvidence) {
      batch.set(db.collection('medical_research_evidence').doc(evidence.evidenceHash), { ...evidence, entityKey, entityName: name, jobId: ref.id, createdAt: FieldValue.serverTimestamp() }, { merge: true });
    }
    if (allEvidence.length) await batch.commit();
    const packet = {
      schemaVersion: 1, workerVersion: '0.2.0', entityKey, entityName: name, jobId: ref.id,
      status: 'needs_review', generatedAt: new Date().toISOString(),
      sourceScope: ['NCBI PubMed', 'NCBI Bookshelf'],
      resultCounts: { pubmedRecords: pubmed.length, bookshelfMatches: bookshelf.length, totalEvidenceItems: allEvidence.length },
      evidenceIds: allEvidence.map(item => item.evidenceHash), findings: [],
      interpretation: 'Este paquete contiene registros bibliográficos recuperados automáticamente. No contiene conclusiones clínicas verificadas. Los títulos, resúmenes y coincidencias deben revisarse individualmente; la presencia de un artículo no demuestra por sí sola que respalde un campo de la ficha.',
      limitations: ['No se realizó evaluación sistemática de riesgo de sesgo.', 'No se extrajeron recomendaciones terapéuticas.', 'No se resolvieron automáticamente sinónimos ni variantes taxonómicas.', 'Los resúmenes pueden estar incompletos y conservar el idioma original.', 'No se ha contrastado todavía cada afirmación con el texto completo.'],
      elapsedMs: Date.now() - started
    };
    await db.collection('medical_research_packets').doc(ref.id).set(packet, { merge: true });
    await ref.update({ status: 'needs_review', evidenceCount: allEvidence.length, pubmedCount: pubmed.length, bookshelfCount: bookshelf.length, packetId: ref.id, completedAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp(), leaseUntilMs: 0, lastError: FieldValue.delete() });
    return { jobId: ref.id, entityName: name, status: 'needs_review', evidenceCount: allEvidence.length };
  } catch (error) {
    const attempts = Number(job.attempts || 1);
    const message = String(error.message || error);
    const terminal = attempts >= 4 || message.includes('ENTITY_REQUIRES_MANUAL_IDENTIFICATION') || message.includes('ENTITY_NAME_NOT_RESEARCHABLE');
    await ref.update({ status: terminal ? 'failed' : 'queued', lastError: message.slice(0, 500), updatedAt: FieldValue.serverTimestamp(), leaseUntilMs: 0, retryAfterMs: terminal ? 0 : Date.now() + Math.min(60 * 60 * 1000, attempts * attempts * 60000) });
    return { jobId: ref.id, status: terminal ? 'failed' : 'queued', error: message.slice(0, 300) };
  }
}

async function getCandidates(db, limit) {
  const now = Date.now();
  const [queued, running] = await Promise.all([
    db.collection('medical_research_jobs').where('status', '==', 'queued').limit(50).get(),
    db.collection('medical_research_jobs').where('status', '==', 'running').limit(50).get()
  ]);
  return [...queued.docs, ...running.docs]
    .filter(doc => {
      const d = doc.data();
      return (d.status === 'queued' && Number(d.retryAfterMs || 0) <= now) || (d.status === 'running' && Number(d.leaseUntilMs || 0) < now);
    })
    .sort((a, b) => Number(a.data().priorityRank || 50) - Number(b.data().priorityRank || 50) || Number(a.data().createdAtMs || 0) - Number(b.data().createdAtMs || 0))
    .slice(0, limit);
}

async function main() {
  initFirebase();
  const db = admin.firestore();
  const docs = await getCandidates(db, MAX_JOBS_PER_RUN);
  const results = [];
  for (const doc of docs) results.push(await processJob(doc.ref, db));
  const summary = { ok: true, projectId: PROJECT_ID, examined: docs.length, results, finishedAt: new Date().toISOString() };
  console.log(JSON.stringify(summary, null, 2));
  return summary;
}

if (require.main === module) main().catch(error => { console.error(`RESEARCH_WORKER_ERROR: ${error.message || error}`); process.exitCode = 1; });
module.exports = { clean, buildSearchTerm, getCandidates };
