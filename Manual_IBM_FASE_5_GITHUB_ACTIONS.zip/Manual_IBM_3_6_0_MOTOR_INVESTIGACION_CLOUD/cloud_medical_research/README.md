# Manual IBM — Motor de investigación documental 0.2.0

## Arquitectura sin servicios de ejecución de Google Cloud

- GitHub Actions ejecuta el proceso manualmente o una vez al día.
- Firebase Firestore continúa siendo la base central de Manual IBM.
- NCBI PubMed y NCBI Bookshelf son las fuentes consultadas en esta versión.
- El worker no abre puertos, no ejecuta un servidor HTTP y no necesita Cloud Run, Cloud Build, Artifact Registry ni Cloud Scheduler.
- Android no ejecuta este motor.

## Colecciones de investigación

| Colección | Uso |
|---|---|
| `medical_research_jobs` | Cola central de trabajos |
| `medical_research_evidence` | Referencias documentales recuperadas |
| `medical_research_packets` | Expedientes que esperan revisión humana |

El motor no escribe en `global_library_chunks`, `global_library_meta`, `published_records` ni `published_maps`. La biblioteca oficial permanece intacta.

## Secretos requeridos en GitHub

En el repositorio: **Settings → Secrets and variables → Actions → New repository secret**.

- `FIREBASE_SERVICE_ACCOUNT_JSON`: contenido completo de la clave JSON de una cuenta de servicio dedicada al motor.
- `NCBI_EMAIL`: opcional; correo de contacto para identificar las consultas a NCBI.

No subir claves JSON, `.env`, credenciales ni datos privados al repositorio. No pegues la clave en Issues, commits ni conversaciones.

**Seguridad importante:** Firebase Admin SDK omite las reglas de seguridad de Firestore. El rol IAM habitual `roles/datastore.user` permite operar sobre la base de datos de forma amplia; no limita permisos solo a estas tres colecciones. Esta versión contiene una restricción en el código para escribir únicamente en las colecciones de investigación, pero eso no es aislamiento IAM. Antes de generar o instalar una clave, hay que revisar y aprobar el alcance IAM de la cuenta. Nunca usar la clave de una cuenta propietaria o con permisos de publicación de la biblioteca.

## Primera carga de cola

El archivo `data/medical_research_backlog.json` conserva la cola de auditoría existente. En GitHub, abrir **Actions → Manual IBM - Cargar cola inicial → Run workflow**. El script comprueba documentos existentes y no los sobrescribe. La carga es una operación manual de una sola vez; repetirla no duplica trabajos.

## Ejecutar investigación

Abrir **Actions → Manual IBM - Investigación médica → Run workflow**. También queda programado una vez al día. Cada ejecución procesa como máximo un trabajo por defecto. La concurrencia está serializada para evitar dos ejecuciones simultáneas.

## Estados y revisión

`queued` → `running` → `needs_review`; errores transitorios regresan a `queued` con espera; errores permanentes o cuatro intentos fallidos quedan `failed`.

Los resultados se guardan como expediente documental y evidencia bibliográfica. No se redactan conclusiones clínicas automáticas, no se extraen tratamientos y no se publica nada en la biblioteca canónica. La recuperación de artículos no demuestra por sí sola que respalden un campo clínico.

## Límites

- Máximo de 3 trabajos por ejecución (1 por defecto).
- Solicitudes NCBI serializadas con espera mínima de 450 ms.
- Hasta 8 registros PubMed y 5 coincidencias de Bookshelf por entidad.
- Lease de 10 minutos para recuperar trabajos interrumpidos.
- Los resúmenes conservan el idioma original; no hay traducción automática.
- GitHub Actions en repositorios públicos suele ofrecer runners estándar sin cargo, sujeto a las políticas y límites vigentes de GitHub. Firestore Spark también tiene cuotas; al agotarse pueden detenerse las operaciones. Esta arquitectura evita activar facturación de Google Cloud, pero hay que respetar ambos límites.

## Pruebas locales

```bash
cd cloud_medical_research
npm install
npm test
```
