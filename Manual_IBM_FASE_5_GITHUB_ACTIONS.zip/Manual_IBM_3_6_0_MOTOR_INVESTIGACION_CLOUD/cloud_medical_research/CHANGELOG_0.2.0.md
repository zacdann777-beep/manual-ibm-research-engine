# 0.2.0 — Adaptación GitHub Actions

- Eliminado Express y el servidor HTTP preparado para Cloud Run.
- El worker ahora se ejecuta como proceso CLI de corta duración.
- Autenticación explícita mediante secreto `FIREBASE_SERVICE_ACCOUNT_JSON`.
- Consultas acotadas de trabajos `queued` y `running` para evitar leer toda la colección.
- Añadidos workflows separados para ejecución programada/manual y carga manual inicial del backlog.
- Añadido control de concurrencia y permisos mínimos de GitHub Actions (`contents: read`).
- Se conserva la separación entre expedientes de investigación y biblioteca oficial.
