'use strict';
const fs = require('node:fs');
const path = require('node:path');
const admin = require('firebase-admin');
const PROJECT_ID = process.env.FIREBASE_PROJECT_ID || 'manual-ibm';
const BACKLOG = process.argv[2] || path.resolve(__dirname, '../data/medical_research_backlog.json');

function initFirebase() {
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (!raw) throw new Error('MISSING_SECRET_FIREBASE_SERVICE_ACCOUNT_JSON');
  let credentials;
  try { credentials = JSON.parse(raw); } catch { throw new Error('INVALID_SECRET_FIREBASE_SERVICE_ACCOUNT_JSON'); }
  admin.initializeApp({ credential: admin.credential.cert(credentials), projectId: PROJECT_ID });
}
const slug = value => String(value).toLowerCase().replace(/[^a-z0-9:_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 700);

async function main() {
  if (!fs.existsSync(BACKLOG)) throw new Error(`No existe backlog: ${BACKLOG}`);
  const backlog = JSON.parse(fs.readFileSync(BACKLOG, 'utf8'));
  if (!Array.isArray(backlog.items)) throw new Error('Formato de backlog inesperado: se esperaba backlog.items');
  initFirebase();
  const db = admin.firestore();
  const FieldValue = admin.firestore.FieldValue;
  let created = 0, existing = 0, skipped = 0;
  const valid = backlog.items.map(item => {
    const name = String(item.name || '').trim();
    const key = String(item.entityKey || '').trim();
    if (!key || !name || /SIN DENOMINACI[ÓO]N|REGISTRO ORIGINAL/i.test(name)) { skipped++; return null; }
    return { item, name, key, id: slug(key) };
  }).filter(Boolean);

  for (let i = 0; i < valid.length; i += 400) {
    const rows = valid.slice(i, i + 400);
    const refs = rows.map(row => db.collection('medical_research_jobs').doc(row.id));
    const snapshots = await db.getAll(...refs);
    const batch = db.batch();
    rows.forEach((row, index) => {
      if (snapshots[index].exists) { existing++; return; }
      const rank = row.item.currentStatus === 'SIN_INFORMACION' ? 10 : row.item.currentStatus === 'PARTIAL' ? 20 : 40;
      batch.create(refs[index], {
        entityKey: row.key, entityName: row.name, sourceStatus: row.item.currentStatus || 'UNKNOWN',
        existingMedicalFields: Number(row.item.existingMedicalFields || 0), priorityRank: rank,
        status: 'queued', attempts: 0, createdAt: FieldValue.serverTimestamp(), createdAtMs: Date.now(),
        updatedAt: FieldValue.serverTimestamp(), origin: 'data/medical_research_backlog.json',
        requiredAction: row.item.requiredAction || 'RESEARCH_WITH_PRIMARY_SOURCES_AND_REVIEW'
      });
      created++;
    });
    await batch.commit();
    console.log(`Lote ${Math.floor(i / 400) + 1}: ${rows.length} entradas verificadas`);
  }
  console.log(JSON.stringify({ projectId: PROJECT_ID, created, alreadyExisted: existing, skipped }, null, 2));
}
main().catch(error => { console.error(`BACKLOG_SEED_ERROR: ${error.message || error}`); process.exitCode = 1; });
