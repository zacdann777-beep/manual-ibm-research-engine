'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { clean, buildSearchTerm } = require('../worker');

test('normaliza texto sin alterar el contenido textual básico', () => assert.equal(clean('<i>Actinomyces</i> &amp; bacteria'), 'Actinomyces & bacteria'));
test('genera una consulta PubMed acotada para una entidad identificable', () => assert.match(buildSearchTerm('Actinomyces'), /Actinomyces/));
test('rechaza nombres vacíos o demasiado cortos', () => assert.throws(() => buildSearchTerm(''), /ENTITY_NAME_NOT_RESEARCHABLE/));
test('rechaza consultas excesivamente largas', () => assert.throws(() => buildSearchTerm('A'.repeat(121)), /ENTITY_NAME_NOT_RESEARCHABLE/));
test('no deja que etiquetas HTML se conviertan en parte del término', () => assert.match(buildSearchTerm('<b>Staphylococcus</b>'), /Staphylococcus/));
